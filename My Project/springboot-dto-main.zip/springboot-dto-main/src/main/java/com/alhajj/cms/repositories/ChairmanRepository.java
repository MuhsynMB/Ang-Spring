package com.alhajj.cms.repositories;

import com.alhajj.cms.model.ChairmanEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChairmanRepository extends JpaRepository<ChairmanEntity, Long> {
}
