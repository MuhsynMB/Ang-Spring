package com.alhajj.cms.repositories;

import com.alhajj.cms.model.ProvinceEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProvinceRepository extends JpaRepository<ProvinceEntity, Long> {
}
