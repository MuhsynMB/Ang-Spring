package com.alhajj.cms.repositories;

import com.alhajj.cms.model.WardEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WardRepository extends JpaRepository<WardEntity, Long> {
}
